
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_automation_triggers`
--

CREATE TABLE `wp_mailpoet_automation_triggers` (
  `automation_id` int(11) UNSIGNED NOT NULL,
  `trigger_key` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
