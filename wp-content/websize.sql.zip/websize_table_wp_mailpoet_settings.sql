
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_settings`
--

CREATE TABLE `wp_mailpoet_settings` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_mailpoet_settings`
--

INSERT INTO `wp_mailpoet_settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'mta_log', 'a:8:{s:4:\"sent\";a:0:{}s:7:\"started\";i:1680161677;s:6:\"status\";N;s:13:\"retry_attempt\";N;s:8:\"retry_at\";N;s:5:\"error\";a:2:{s:9:\"operation\";s:4:\"send\";s:13:\"error_message\";s:36:\"Could not instantiate mail function.\";}s:33:\"transactional_email_last_error_at\";i:1682581316;s:31:\"transactional_email_error_count\";i:2;}', '2023-03-30 07:34:33', '2023-05-30 14:34:57'),
(2, 'homepage', 'a:1:{s:27:\"product_discovery_dismissed\";b:0;}', '2023-03-30 07:34:33', '2023-03-30 07:34:33'),
(3, 'cron_trigger', 'a:1:{s:6:\"method\";s:16:\"Action Scheduler\";}', '2023-03-30 07:34:37', '2023-03-30 07:34:37'),
(4, 'sender', 'a:2:{s:4:\"name\";s:5:\"admin\";s:7:\"address\";s:19:\"wordpress@localhost\";}', '2023-03-30 07:34:37', '2023-05-26 15:21:47'),
(5, 'signup_confirmation', 'a:4:{s:7:\"enabled\";b:1;s:4:\"from\";a:2:{s:7:\"address\";s:19:\"wordpress@localhost\";s:4:\"name\";s:5:\"admin\";}s:8:\"reply_to\";a:2:{s:7:\"address\";s:15:\"admin@gmail.com\";s:4:\"name\";s:5:\"admin\";}s:22:\"transactional_email_id\";i:1;}', '2023-03-30 07:34:37', '2023-05-26 15:21:47'),
(6, 'installed_at', '2023-03-30 07:34:37', '2023-03-30 07:34:37', '2023-03-30 07:34:37'),
(7, 'captcha', 'a:3:{s:4:\"type\";N;s:20:\"recaptcha_site_token\";s:0:\"\";s:22:\"recaptcha_secret_token\";s:0:\"\";}', '2023-03-30 07:34:37', '2023-03-30 07:34:37'),
(8, 'subscriber_email_notification', 'a:3:{s:7:\"enabled\";b:1;s:9:\"automated\";b:1;s:7:\"address\";s:15:\"admin@gmail.com\";}', '2023-03-30 07:34:37', '2023-03-30 07:34:37'),
(9, 'stats_notifications', 'a:2:{s:7:\"enabled\";b:1;s:7:\"address\";s:15:\"admin@gmail.com\";}', '2023-03-30 07:34:37', '2023-03-30 07:34:37'),
(10, 'woocommerce', 'a:2:{s:17:\"optin_on_checkout\";a:2:{s:7:\"enabled\";b:1;s:7:\"message\";s:79:\"I would like to receive exclusive emails with discounts and product information\";}s:30:\"accept_cookie_revenue_tracking\";a:1:{s:3:\"set\";s:1:\"1\";}}', '2023-03-30 07:34:37', '2023-05-26 15:22:54'),
(12, 'subscription', 'a:1:{s:5:\"pages\";a:5:{s:11:\"unsubscribe\";i:11;s:6:\"manage\";i:11;s:12:\"confirmation\";i:11;s:7:\"captcha\";i:11;s:19:\"confirm_unsubscribe\";i:11;}}', '2023-03-30 07:34:38', '2023-03-30 07:34:38'),
(13, 'db_version', '4.10.0', '2023-03-30 07:34:38', '2023-03-30 07:34:38'),
(14, 'updates_log', 'a:1:{i:0;a:3:{s:16:\"previous_version\";N;s:11:\"new_version\";s:6:\"4.10.0\";s:4:\"date\";s:19:\"2023-03-30 07:34:38\";}}', '2023-03-30 07:34:38', '2023-03-30 07:34:38'),
(15, 'queue_disabled_mail_function_check', '1', '2023-03-30 07:34:39', '2023-03-30 07:34:39'),
(16, 'cron_daemon', 'a:8:{s:5:\"token\";s:5:\"tcndf\";s:6:\"status\";s:6:\"active\";s:15:\"run_accessed_at\";N;s:14:\"run_started_at\";i:1685457297;s:16:\"run_completed_at\";i:1685457298;s:10:\"last_error\";N;s:15:\"last_error_date\";N;s:10:\"updated_at\";i:1685457298;}', '2023-03-30 07:35:20', '2023-05-30 14:34:58'),
(19, 'last_announcement_date', '1679728785', '2023-03-30 07:35:20', '2023-05-23 14:14:57'),
(66, 'show_congratulate_after_first_newsletter', '1', '2023-04-11 14:33:58', '2023-05-30 05:34:22'),
(162, 'reply_to', 'a:2:{s:4:\"name\";s:5:\"admin\";s:7:\"address\";s:15:\"admin@gmail.com\";}', '2023-05-26 14:24:56', '2023-05-26 15:21:47'),
(168, 'authorized_emails_addresses_check', NULL, '2023-05-26 14:24:56', '2023-05-26 15:21:47'),
(173, 'analytics', 'a:1:{s:7:\"enabled\";s:1:\"1\";}', '2023-05-26 14:26:03', '2023-05-26 15:22:38'),
(174, '3rd_party_libs', 'a:1:{s:7:\"enabled\";s:1:\"1\";}', '2023-05-26 14:26:03', '2023-05-26 15:22:38'),
(175, 'woocommerce_import_screen_displayed', '1', '2023-05-26 14:26:21', '2023-05-26 15:22:54'),
(176, 'mailpoet_subscribe_old_woocommerce_customers', 'a:1:{s:7:\"enabled\";s:1:\"1\";}', '2023-05-26 14:26:21', '2023-05-26 15:22:54'),
(177, 'tracking', 'a:1:{s:5:\"level\";s:4:\"full\";}', '2023-05-26 14:26:21', '2023-05-26 15:22:54'),
(184, 'analytics_last_sent', '2023-05-26 15:20:52', '2023-05-26 15:20:52', '2023-05-26 15:20:52'),
(186, 'public_id', 'fd0e96b1f9f8af9e2119d04473c7d96c', '2023-05-26 15:21:16', '2023-05-26 15:21:16'),
(187, 'new_public_id', 'false', '2023-05-26 15:21:16', '2023-05-26 15:21:16');
