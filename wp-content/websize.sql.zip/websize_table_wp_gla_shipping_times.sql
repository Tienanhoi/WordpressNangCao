
-- --------------------------------------------------------

--
-- Table structure for table `wp_gla_shipping_times`
--

CREATE TABLE `wp_gla_shipping_times` (
  `id` bigint(20) NOT NULL,
  `country` varchar(2) NOT NULL,
  `time` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
