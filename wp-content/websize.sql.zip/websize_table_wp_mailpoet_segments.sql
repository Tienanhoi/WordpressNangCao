
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_segments`
--

CREATE TABLE `wp_mailpoet_segments` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(90) NOT NULL,
  `type` varchar(90) NOT NULL DEFAULT 'default',
  `description` varchar(250) NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `average_engagement_score` float UNSIGNED DEFAULT NULL,
  `average_engagement_score_updated_at` timestamp NULL DEFAULT NULL,
  `display_in_manage_subscription_page` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_mailpoet_segments`
--

INSERT INTO `wp_mailpoet_segments` (`id`, `name`, `type`, `description`, `created_at`, `updated_at`, `deleted_at`, `average_engagement_score`, `average_engagement_score_updated_at`, `display_in_manage_subscription_page`) VALUES
(1, 'WordPress Users', 'wp_users', 'This list contains all of your WordPress users.', '2023-03-30 07:34:29', '2023-05-29 14:27:40', NULL, NULL, '2023-05-29 14:27:45', 0),
(2, 'WooCommerce Customers', 'woocommerce_users', 'This list contains all of your WooCommerce customers.', '2023-03-30 07:34:29', '2023-05-29 14:27:40', NULL, NULL, '2023-05-29 14:27:45', 0),
(3, 'Newsletter mailing list', 'default', 'This list is automatically created when you install MailPoet.', '2023-03-30 07:34:29', '2023-05-29 14:27:40', NULL, NULL, '2023-05-29 14:27:45', 0);
