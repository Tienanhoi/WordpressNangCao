
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_newsletter_links`
--

CREATE TABLE `wp_mailpoet_newsletter_links` (
  `id` int(11) UNSIGNED NOT NULL,
  `newsletter_id` int(11) UNSIGNED NOT NULL,
  `queue_id` int(11) UNSIGNED NOT NULL,
  `url` varchar(2083) NOT NULL,
  `hash` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
