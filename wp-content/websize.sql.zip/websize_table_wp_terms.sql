
-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Chưa phân loại', 'khong-phan-loai', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Chưa phân loại', 'chua-phan-loai', 0),
(16, 'Máy Quay - Camera Action - FlyCam', 'may-quay-camera-action-flycam-vi', 0),
(17, 'camera 360', 'camera-360', 0),
(18, 'đen', 'den', 0),
(19, 'trắng', 'trang', 0),
(20, 'Máy Ảnh', 'may-anh-vi', 0),
(21, 'chỉ body', 'chi-body', 0),
(22, 'kèm Lens 16-50mm', 'kem-lens-16-50mm', 0),
(23, 'Máy In', 'may-in-vi', 0),
(24, 'menu tiếng việt', 'menu-tieng-viet', 0),
(25, 'Tiếng Việt', 'vi', 0),
(26, 'Tiếng Việt', 'pll_vi', 0),
(27, 'pll_64721de69651c', 'pll_64721de69651c', 0),
(28, 'English', 'en', 0),
(29, 'English', 'pll_en', 0),
(30, 'Uncategorized', 'uncategorized-en', 0),
(32, 'pll_64721e6ee4389', 'pll_64721e6ee4389', 0),
(33, 'pll_6474d1ed02d24', 'pll_6474d1ed02d24', 0),
(34, 'pll_6474d2e3573c9', 'pll_6474d2e3573c9', 0),
(35, 'pll_6474d39a861d3', 'pll_6474d39a861d3', 0),
(37, 'pll_647564ca8eec2', 'pll_647564ca8eec2', 0),
(38, 'Printer', 'may-in-en', 0),
(39, 'pll_6475960a5cab9', 'pll_6475960a5cab9', 0),
(40, 'pll_6475960a919c6', 'pll_6475960a919c6', 0),
(43, 'Chưa phân loại', 'chua-phan-loai-vi', 0),
(44, 'pll_64759a5fe2efc', 'pll_64759a5fe2efc', 0),
(45, 'pll_6475b0d1bdfd4', 'pll_6475b0d1bdfd4', 0),
(46, 'pll_6475b182a8a0c', 'pll_6475b182a8a0c', 0),
(48, 'pll_6475b28aab3f5', 'pll_6475b28aab3f5', 0),
(49, 'Camcorder - Action Camera - FlyCam', 'camcorder-action-camera-flycam', 0),
(51, 'pll_6475b42784bb8', 'pll_6475b42784bb8', 0),
(52, 'Camera', 'camera', 0),
(54, 'pll_6475b7faa67d9', 'pll_6475b7faa67d9', 0),
(55, 'pll_6475bdf8b3c7f', 'pll_6475bdf8b3c7f', 0),
(56, 'pll_6475c077eea5e', 'pll_6475c077eea5e', 0),
(57, 'pll_6475c438ad4d0', 'pll_6475c438ad4d0', 0),
(58, 'pll_6475c80fde53f', 'pll_6475c80fde53f', 0),
(59, 'pll_6475cbd3871a4', 'pll_6475cbd3871a4', 0),
(60, 'pll_6475cdd4910f1', 'pll_6475cdd4910f1', 0),
(61, 'pll_6475cff43a907', 'pll_6475cff43a907', 0),
(62, 'pll_6475d4191581d', 'pll_6475d4191581d', 0),
(63, 'pll_6475d66f6aaac', 'pll_6475d66f6aaac', 0),
(64, 'camera 360', 'camera-360-en', 0),
(65, 'pll_6475d89c0be21', 'pll_6475d89c0be21', 0),
(66, 'pll_6475d89c18500', 'pll_6475d89c18500', 0),
(67, 'pll_6475d926ba053', 'pll_6475d926ba053', 0),
(68, 'camera 360', 'camera-360-vi', 0),
(69, 'pll_6475d928c6b65', 'pll_6475d928c6b65', 0),
(70, 'pll_6475d929696b0', 'pll_6475d929696b0', 0),
(71, 'menu tiếng anh', 'menu-tieng-anh', 0);
