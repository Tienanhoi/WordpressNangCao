
-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 20),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 6),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(16, 16, 'product_cat', '', 0, 6),
(17, 17, 'product_tag', '', 0, 1),
(18, 18, 'pa_mau-sac', '', 0, 16),
(19, 19, 'pa_mau-sac', '', 0, 6),
(20, 20, 'product_cat', '', 0, 5),
(21, 21, 'pa_tuy-chon', '', 0, 2),
(22, 22, 'pa_tuy-chon', '', 0, 2),
(23, 23, 'product_cat', '', 0, 2),
(24, 24, 'nav_menu', '', 0, 6),
(25, 25, 'language', 'a:3:{s:6:\"locale\";s:2:\"vi\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:2:\"vn\";}', 0, 86),
(26, 26, 'term_language', '', 0, 6),
(27, 27, 'term_translations', 'a:2:{s:2:\"vi\";i:1;s:2:\"en\";i:30;}', 0, 2),
(28, 28, 'language', 'a:3:{s:6:\"locale\";s:5:\"en_US\";s:3:\"rtl\";i:0;s:9:\"flag_code\";s:2:\"us\";}', 0, 23),
(29, 29, 'term_language', '', 0, 5),
(30, 30, 'category', '', 0, 0),
(32, 32, 'post_translations', 'a:2:{s:2:\"vi\";i:22;s:2:\"en\";i:220;}', 0, 2),
(33, 33, 'post_translations', 'a:2:{s:2:\"en\";i:243;s:2:\"vi\";i:6;}', 0, 2),
(34, 34, 'post_translations', 'a:2:{s:2:\"vi\";i:7;s:2:\"en\";i:344;}', 0, 2),
(35, 35, 'post_translations', 'a:2:{s:2:\"vi\";i:9;s:2:\"en\";i:346;}', 0, 2),
(37, 37, 'post_translations', 'a:2:{s:2:\"vi\";i:8;s:2:\"en\";i:345;}', 0, 2),
(38, 38, 'product_cat', '', 0, 2),
(39, 39, 'term_translations', 'a:1:{s:2:\"vi\";i:38;}', 0, 0),
(40, 40, 'term_translations', 'a:1:{s:2:\"en\";i:38;}', 0, 1),
(43, 43, 'product_cat', '', 0, 0),
(44, 44, 'term_translations', 'a:1:{s:2:\"vi\";i:43;}', 0, 1),
(45, 45, 'term_translations', 'a:1:{s:2:\"vi\";i:23;}', 0, 1),
(46, 46, 'term_translations', 'a:1:{s:2:\"vi\";i:41;}', 0, 0),
(48, 48, 'term_translations', 'a:2:{s:2:\"vi\";i:16;s:2:\"en\";i:49;}', 0, 2),
(49, 49, 'product_cat', '', 0, 6),
(51, 51, 'term_translations', 'a:2:{s:2:\"vi\";i:20;s:2:\"en\";i:52;}', 0, 2),
(52, 52, 'product_cat', '', 0, 5),
(54, 54, 'post_translations', 'a:2:{s:2:\"en\";i:296;s:2:\"vi\";i:107;}', 0, 2),
(55, 55, 'post_translations', 'a:2:{s:2:\"en\";i:298;s:2:\"vi\";i:119;}', 0, 2),
(56, 56, 'post_translations', 'a:2:{s:2:\"en\";i:300;s:2:\"vi\";i:299;}', 0, 2),
(57, 57, 'post_translations', 'a:2:{s:2:\"en\";i:301;s:2:\"vi\";i:87;}', 0, 2),
(58, 58, 'post_translations', 'a:2:{s:2:\"en\";i:305;s:2:\"vi\";i:79;}', 0, 2),
(59, 59, 'post_translations', 'a:2:{s:2:\"en\";i:310;s:2:\"vi\";i:70;}', 0, 2),
(60, 60, 'post_translations', 'a:2:{s:2:\"en\";i:312;s:2:\"vi\";i:55;}', 0, 2),
(61, 61, 'post_translations', 'a:2:{s:2:\"en\";i:314;s:2:\"vi\";i:48;}', 0, 2),
(62, 62, 'post_translations', 'a:2:{s:2:\"en\";i:316;s:2:\"vi\";i:37;}', 0, 2),
(63, 63, 'post_translations', 'a:2:{s:2:\"en\";i:318;s:2:\"vi\";i:64;}', 0, 2),
(64, 64, 'product_tag', '', 0, 0),
(65, 65, 'term_translations', 'a:1:{s:2:\"vi\";i:64;}', 0, 0),
(66, 66, 'term_translations', 'a:1:{s:2:\"en\";i:64;}', 0, 1),
(67, 67, 'post_translations', 'a:2:{s:2:\"en\";i:319;s:2:\"vi\";i:14;}', 0, 2),
(68, 68, 'product_tag', '', 0, 1),
(69, 69, 'term_translations', 'a:1:{s:2:\"en\";i:68;}', 0, 0),
(70, 70, 'term_translations', 'a:1:{s:2:\"vi\";i:68;}', 0, 1),
(71, 71, 'nav_menu', '', 0, 6);
