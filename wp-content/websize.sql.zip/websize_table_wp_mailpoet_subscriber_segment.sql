
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_subscriber_segment`
--

CREATE TABLE `wp_mailpoet_subscriber_segment` (
  `id` int(11) UNSIGNED NOT NULL,
  `subscriber_id` int(11) UNSIGNED NOT NULL,
  `segment_id` int(11) UNSIGNED NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT 'subscribed',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_mailpoet_subscriber_segment`
--

INSERT INTO `wp_mailpoet_subscriber_segment` (`id`, `subscriber_id`, `segment_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'subscribed', '2023-03-30 07:34:37', '2023-03-30 07:34:37'),
(2, 1, 2, 'subscribed', '2023-04-20 07:46:14', '2023-04-20 07:46:14');
