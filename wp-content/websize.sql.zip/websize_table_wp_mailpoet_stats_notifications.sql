
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_stats_notifications`
--

CREATE TABLE `wp_mailpoet_stats_notifications` (
  `id` int(11) UNSIGNED NOT NULL,
  `newsletter_id` int(11) UNSIGNED NOT NULL,
  `task_id` int(11) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
