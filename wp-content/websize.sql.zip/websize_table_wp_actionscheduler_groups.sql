
-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_groups`
--

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_actionscheduler_groups`
--

INSERT INTO `wp_actionscheduler_groups` (`group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'gla'),
(3, 'mailpoet-cron'),
(4, 'mailpoet-cron'),
(5, 'pinterest-for-woocommerce'),
(6, 'woocommerce-db-updates'),
(7, 'wc-admin-data'),
(8, 'tt4b_version_{\"version\":\"1.0.16\"}'),
(9, 'wc_update_product_default_cat');
