
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_automation_run_subjects`
--

CREATE TABLE `wp_mailpoet_automation_run_subjects` (
  `id` int(11) UNSIGNED NOT NULL,
  `automation_run_id` int(11) UNSIGNED NOT NULL,
  `key` varchar(191) DEFAULT NULL,
  `args` longtext DEFAULT NULL,
  `hash` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
