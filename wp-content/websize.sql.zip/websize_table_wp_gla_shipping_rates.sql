
-- --------------------------------------------------------

--
-- Table structure for table `wp_gla_shipping_rates`
--

CREATE TABLE `wp_gla_shipping_rates` (
  `id` bigint(20) NOT NULL,
  `country` varchar(2) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `rate` double NOT NULL DEFAULT 0,
  `options` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
