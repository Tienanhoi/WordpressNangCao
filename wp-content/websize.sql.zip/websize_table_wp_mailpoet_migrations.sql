
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_migrations`
--

CREATE TABLE `wp_mailpoet_migrations` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  `retries` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `error` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_mailpoet_migrations`
--

INSERT INTO `wp_mailpoet_migrations` (`id`, `name`, `started_at`, `completed_at`, `retries`, `error`) VALUES
(1, 'Migration_20221028_105818', '2023-03-30 07:34:32', '2023-03-30 07:34:32', 0, NULL),
(2, 'Migration_20221110_151621', '2023-03-30 07:34:33', '2023-03-30 07:34:33', 0, NULL),
(3, 'Migration_20230109_144830', '2023-03-30 07:34:33', '2023-03-30 07:34:33', 0, NULL),
(4, 'Migration_20230111_120000', '2023-03-30 07:34:33', '2023-03-30 07:34:33', 0, NULL),
(5, 'Migration_20230111_130000', '2023-03-30 07:34:33', '2023-03-30 07:34:33', 0, NULL),
(6, 'Migration_20230131_121621', '2023-03-30 07:34:33', '2023-03-30 07:34:33', 0, NULL),
(7, 'Migration_20230215_050813', '2023-03-30 07:34:33', '2023-03-30 07:34:33', 0, NULL),
(8, 'Migration_20230221_200520', '2023-03-30 07:34:33', '2023-03-30 07:34:33', 0, NULL);
