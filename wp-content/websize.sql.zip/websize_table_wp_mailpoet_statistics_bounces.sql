
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_statistics_bounces`
--

CREATE TABLE `wp_mailpoet_statistics_bounces` (
  `id` int(11) UNSIGNED NOT NULL,
  `newsletter_id` int(11) UNSIGNED NOT NULL,
  `subscriber_id` int(11) UNSIGNED NOT NULL,
  `queue_id` int(11) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
