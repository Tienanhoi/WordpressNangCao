
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_automation_runs`
--

CREATE TABLE `wp_mailpoet_automation_runs` (
  `id` int(11) UNSIGNED NOT NULL,
  `automation_id` int(11) UNSIGNED NOT NULL,
  `version_id` int(11) UNSIGNED NOT NULL,
  `trigger_key` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `next_step_id` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
