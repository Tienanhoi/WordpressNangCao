
-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_items`
--

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_woocommerce_order_items`
--

INSERT INTO `wp_woocommerce_order_items` (`order_item_id`, `order_item_name`, `order_item_type`, `order_id`) VALUES
(1, 'Insta360 One X3 , Mới 100% (Chính hãng)', 'line_item', 140),
(2, 'Giao hàng miễn phí', 'shipping', 140),
(3, 'Sony ZV-E10 (Body) (Màu đen), Mới 100% (Chính hãng)', 'line_item', 204),
(4, 'Canon EOS R + RF 24-105mm F4L, Mới 100%(Chính  Hãng)', 'line_item', 204),
(5, 'Máy in Canon SELPHY CP1500, Mới 100% (Chính hãng)', 'line_item', 204),
(6, 'Giao hàng miễn phí', 'shipping', 204),
(7, 'tienanhmaidinh', 'coupon', 204);
