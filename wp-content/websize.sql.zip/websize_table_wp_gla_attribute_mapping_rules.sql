
-- --------------------------------------------------------

--
-- Table structure for table `wp_gla_attribute_mapping_rules`
--

CREATE TABLE `wp_gla_attribute_mapping_rules` (
  `id` bigint(20) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `source` varchar(100) NOT NULL,
  `category_condition_type` varchar(10) NOT NULL,
  `categories` text DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
