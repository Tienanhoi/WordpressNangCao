
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_dynamic_segment_filters`
--

CREATE TABLE `wp_mailpoet_dynamic_segment_filters` (
  `id` int(11) UNSIGNED NOT NULL,
  `segment_id` int(11) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `filter_data` longblob DEFAULT NULL,
  `filter_type` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
