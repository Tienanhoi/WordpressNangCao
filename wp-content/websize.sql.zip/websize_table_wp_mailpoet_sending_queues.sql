
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_sending_queues`
--

CREATE TABLE `wp_mailpoet_sending_queues` (
  `id` int(11) UNSIGNED NOT NULL,
  `task_id` int(11) UNSIGNED NOT NULL,
  `newsletter_id` int(11) UNSIGNED DEFAULT NULL,
  `newsletter_rendered_body` longtext DEFAULT NULL,
  `newsletter_rendered_subject` varchar(250) DEFAULT NULL,
  `subscribers` longtext DEFAULT NULL,
  `count_total` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `count_processed` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `count_to_process` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `meta` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
