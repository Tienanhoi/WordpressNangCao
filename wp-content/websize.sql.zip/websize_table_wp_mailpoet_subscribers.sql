
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_subscribers`
--

CREATE TABLE `wp_mailpoet_subscribers` (
  `id` int(11) UNSIGNED NOT NULL,
  `wp_user_id` bigint(20) DEFAULT NULL,
  `is_woocommerce_user` int(1) NOT NULL DEFAULT 0,
  `first_name` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(150) NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT 'unconfirmed',
  `subscribed_ip` varchar(45) DEFAULT NULL,
  `confirmed_ip` varchar(45) DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `last_subscribed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `unconfirmed_data` longtext DEFAULT NULL,
  `source` enum('form','imported','administrator','api','wordpress_user','woocommerce_user','woocommerce_checkout','unknown') DEFAULT 'unknown',
  `count_confirmations` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `unsubscribe_token` char(15) DEFAULT NULL,
  `link_token` char(32) DEFAULT NULL,
  `engagement_score` float UNSIGNED DEFAULT NULL,
  `engagement_score_updated_at` timestamp NULL DEFAULT NULL,
  `last_engagement_at` timestamp NULL DEFAULT NULL,
  `woocommerce_synced_at` timestamp NULL DEFAULT NULL,
  `email_count` int(11) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_mailpoet_subscribers`
--

INSERT INTO `wp_mailpoet_subscribers` (`id`, `wp_user_id`, `is_woocommerce_user`, `first_name`, `last_name`, `email`, `status`, `subscribed_ip`, `confirmed_ip`, `confirmed_at`, `last_subscribed_at`, `created_at`, `updated_at`, `deleted_at`, `unconfirmed_data`, `source`, `count_confirmations`, `unsubscribe_token`, `link_token`, `engagement_score`, `engagement_score_updated_at`, `last_engagement_at`, `woocommerce_synced_at`, `email_count`) VALUES
(1, 1, 1, 'Tiến', '1', 'admin@gmail.com', 'unconfirmed', NULL, NULL, NULL, NULL, '2023-03-30 07:34:37', '2023-05-31 12:03:51', NULL, NULL, 'woocommerce_checkout', 0, '1y9zj77ot5wgg0w', 'a9642b', NULL, '2023-05-03 13:41:43', '2023-05-31 12:03:57', '2023-05-26 15:25:31', 0);
