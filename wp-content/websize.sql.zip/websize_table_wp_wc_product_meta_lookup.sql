
-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_product_meta_lookup`
--

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) DEFAULT 'taxable',
  `tax_class` varchar(100) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_wc_product_meta_lookup`
--

INSERT INTO `wp_wc_product_meta_lookup` (`product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(14, 'Insta360 X3', 0, 0, '11990000.0000', '11990000.0000', 1, NULL, 'instock', 0, '0.00', 3, 'taxable', ''),
(37, '', 0, 0, '6490000.0000', '6490000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(48, '', 0, 0, '10900000.0000', '10900000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(55, '', 0, 0, '12500000.0000', '12500000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(64, '', 0, 0, '7490000.0000', '7490000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(70, '', 0, 0, '16500000.0000', '16500000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(79, '', 0, 0, '4500000.0000', '16000000.0000', 0, NULL, 'instock', 0, '0.00', 1, 'taxable', ''),
(85, '', 0, 0, '16000000.0000', '16000000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(86, '', 0, 0, '4500000.0000', '4500000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(87, '', 0, 0, '24990000.0000', '24990000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(100, '', 0, 0, '24990000.0000', '24990000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(101, '', 0, 0, '32900000.0000', '32900000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(107, '', 0, 0, '33900000.0000', '33900000.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(117, '', 0, 0, '33900000.0000', '33900000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(119, '', 0, 0, '68890000.0000', '68890000.0000', 1, NULL, 'instock', 0, '0.00', 2, 'taxable', ''),
(130, '', 0, 0, '5390000.0000', '5390000.0000', 1, NULL, 'instock', 0, '0.00', 1, 'taxable', ''),
(210, '', 0, 0, '3790000.0000', '3790000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(274, '', 0, 0, '3790000.0000', '3790000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(295, '', 0, 0, '5390000.0000', '5390000.0000', 1, NULL, 'instock', 0, '0.00', 1, 'taxable', ''),
(296, '', 0, 0, '33900000.0000', '33900000.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(297, '', 0, 0, '33900000.0000', '33900000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(298, '', 0, 0, '68890000.0000', '68890000.0000', 1, NULL, 'instock', 0, '0.00', 2, 'taxable', ''),
(299, '', 0, 0, '32900000.0000', '32900000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(300, '', 0, 0, '32900000.0000', '32900000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(301, '', 0, 0, '24990000.0000', '24990000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(302, '', 0, 0, '24990000.0000', '24990000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(305, '', 0, 0, '4500000.0000', '16000000.0000', 0, NULL, 'instock', 0, '0.00', 1, 'taxable', ''),
(306, '', 0, 0, '16000000.0000', '16000000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(307, '', 0, 0, '4500000.0000', '4500000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(310, '', 0, 0, '16500000.0000', '16500000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(312, '', 0, 0, '12500000.0000', '12500000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(314, '', 0, 0, '10900000.0000', '10900000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(316, '', 0, 0, '6490000.0000', '6490000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(318, '', 0, 0, '7490000.0000', '7490000.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(319, 'Insta360 X3', 0, 0, '11990000.0000', '11990000.0000', 1, NULL, 'instock', 0, '0.00', 3, 'taxable', '');
