
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_user_flags`
--

CREATE TABLE `wp_mailpoet_user_flags` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
