
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_statistics_unsubscribes`
--

CREATE TABLE `wp_mailpoet_statistics_unsubscribes` (
  `id` int(11) UNSIGNED NOT NULL,
  `newsletter_id` int(11) UNSIGNED DEFAULT NULL,
  `subscriber_id` int(11) UNSIGNED NOT NULL,
  `queue_id` int(11) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `source` varchar(255) DEFAULT 'unknown',
  `meta` varchar(255) DEFAULT NULL,
  `method` varchar(40) NOT NULL DEFAULT 'unknown'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
