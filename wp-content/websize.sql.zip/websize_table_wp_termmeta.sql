
-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 15, 'product_count_product_cat', '0'),
(2, 16, 'order', '0'),
(3, 16, 'display_type', ''),
(4, 16, 'thumbnail_id', '73'),
(5, 16, 'product_count_product_cat', '6'),
(6, 17, 'product_count_product_tag', '1'),
(7, 18, 'order', '0'),
(8, 19, 'order', '0'),
(9, 20, 'order', '0'),
(10, 20, 'display_type', ''),
(11, 20, 'thumbnail_id', '78'),
(12, 21, 'order', '0'),
(13, 22, 'order', '0'),
(14, 20, 'product_count_product_cat', '5'),
(15, 23, 'order', '0'),
(16, 23, 'display_type', ''),
(17, 23, 'thumbnail_id', '129'),
(18, 23, 'product_count_product_cat', '2'),
(19, 38, 'order', '0'),
(20, 38, 'product_count_product_cat', '2'),
(23, 43, 'order', '0'),
(24, 43, 'product_count_product_cat', '0'),
(27, 38, 'display_type', ''),
(28, 38, 'thumbnail_id', '129'),
(29, 49, 'order', '0'),
(30, 49, 'display_type', ''),
(31, 49, 'thumbnail_id', '73'),
(32, 52, 'order', '0'),
(33, 52, 'display_type', ''),
(34, 52, 'thumbnail_id', '78'),
(35, 52, 'product_count_product_cat', '5'),
(36, 49, 'product_count_product_cat', '6'),
(37, 64, 'product_count_product_tag', '0'),
(38, 68, 'product_count_product_tag', '1'),
(39, 25, '_pll_strings_translations', 'a:26:{i:0;a:2:{i:0;s:278:\"Thông tin cá nhân của bạn sẽ được sử dụng để tăng cường trải nghiệm sử dụng website, để quản lý truy cập vào tài khoản của bạn, và cho các mục đích cụ thể khác được mô tả trong [privacy_policy] của chúng tôi.\";i:1;s:278:\"Thông tin cá nhân của bạn sẽ được sử dụng để tăng cường trải nghiệm sử dụng website, để quản lý truy cập vào tài khoản của bạn, và cho các mục đích cụ thể khác được mô tả trong [privacy_policy] của chúng tôi.\";}i:1;a:2:{i:0;s:10:\"màu sắc\";i:1;s:10:\"màu sắc\";}i:2;a:2:{i:0;s:11:\"Tùy chọn\";i:1;s:11:\"Tùy chọn\";}i:3;a:2:{i:0;s:14:\"tienanhmaidinh\";i:1;s:14:\"tienanhmaidinh\";}i:4;a:2:{i:0;s:35:\"Trả tiền mặt khi nhận hàng\";i:1;s:35:\"Trả tiền mặt khi nhận hàng\";}i:5;a:2:{i:0;s:33:\"Trả tiền mặt khi giao hàng\";i:1;s:33:\"Trả tiền mặt khi giao hàng\";}i:6;a:2:{i:0;s:11:\"Share this:\";i:1;s:11:\"Share this:\";}i:7;a:2:{i:0;s:25:\"thiết bị điện tử\";i:1;s:25:\"thiết bị điện tử\";}i:8;a:2:{i:0;s:6:\"j F, Y\";i:1;s:6:\"j F, Y\";}i:9;a:2:{i:0;s:5:\"g:i a\";i:1;s:5:\"g:i a\";}i:10;a:2:{i:0;s:45:\"{site_title} &mdash; Built with {WooCommerce}\";i:1;s:45:\"{site_title} &mdash; Built with {WooCommerce}\";}i:11;a:2:{i:0;s:15:\"admin@gmail.com\";i:1;s:15:\"admin@gmail.com\";}i:12;a:2:{i:0;s:9:\"order-pay\";i:1;s:9:\"order-pay\";}i:13;a:2:{i:0;s:14:\"order-received\";i:1;s:14:\"order-received\";}i:14;a:2:{i:0;s:6:\"orders\";i:1;s:6:\"orders\";}i:15;a:2:{i:0;s:10:\"view-order\";i:1;s:10:\"view-order\";}i:16;a:2:{i:0;s:9:\"downloads\";i:1;s:9:\"downloads\";}i:17;a:2:{i:0;s:12:\"edit-account\";i:1;s:12:\"edit-account\";}i:18;a:2:{i:0;s:12:\"edit-address\";i:1;s:12:\"edit-address\";}i:19;a:2:{i:0;s:15:\"payment-methods\";i:1;s:15:\"payment-methods\";}i:20;a:2:{i:0;s:13:\"lost-password\";i:1;s:13:\"lost-password\";}i:21;a:2:{i:0;s:15:\"customer-logout\";i:1;s:15:\"customer-logout\";}i:22;a:2:{i:0;s:18:\"add-payment-method\";i:1;s:18:\"add-payment-method\";}i:23;a:2:{i:0;s:21:\"delete-payment-method\";i:1;s:21:\"delete-payment-method\";}i:24;a:2:{i:0;s:26:\"set-default-payment-method\";i:1;s:26:\"set-default-payment-method\";}i:25;a:2:{i:0;s:237:\"Thông tin cá nhân của bạn sẽ được sử dụng để xử lý đơn hàng, tăng trải nghiệm sử dụng website, và cho các mục đích cụ thể khác đã được mô tả trong [privacy_policy] của chúng tôi.\";i:1;s:237:\"Thông tin cá nhân của bạn sẽ được sử dụng để xử lý đơn hàng, tăng trải nghiệm sử dụng website, và cho các mục đích cụ thể khác đã được mô tả trong [privacy_policy] của chúng tôi.\";}}'),
(40, 28, '_pll_strings_translations', 'a:26:{i:0;a:2:{i:0;s:278:\"Thông tin cá nhân của bạn sẽ được sử dụng để tăng cường trải nghiệm sử dụng website, để quản lý truy cập vào tài khoản của bạn, và cho các mục đích cụ thể khác được mô tả trong [privacy_policy] của chúng tôi.\";i:1;s:278:\"Thông tin cá nhân của bạn sẽ được sử dụng để tăng cường trải nghiệm sử dụng website, để quản lý truy cập vào tài khoản của bạn, và cho các mục đích cụ thể khác được mô tả trong [privacy_policy] của chúng tôi.\";}i:1;a:2:{i:0;s:10:\"màu sắc\";i:1;s:5:\"color\";}i:2;a:2:{i:0;s:11:\"Tùy chọn\";i:1;s:6:\"Option\";}i:3;a:2:{i:0;s:14:\"tienanhmaidinh\";i:1;s:14:\"tienanhmaidinh\";}i:4;a:2:{i:0;s:35:\"Trả tiền mặt khi nhận hàng\";i:1;s:16:\"Cash on delivery\";}i:5;a:2:{i:0;s:33:\"Trả tiền mặt khi giao hàng\";i:1;s:16:\"Cash on delivery\";}i:6;a:2:{i:0;s:11:\"Share this:\";i:1;s:11:\"Share this:\";}i:7;a:2:{i:0;s:25:\"thiết bị điện tử\";i:1;s:17:\"electronic device\";}i:8;a:2:{i:0;s:6:\"j F, Y\";i:1;s:6:\"j F, Y\";}i:9;a:2:{i:0;s:5:\"g:i a\";i:1;s:5:\"g:i a\";}i:10;a:2:{i:0;s:45:\"{site_title} &mdash; Built with {WooCommerce}\";i:1;s:45:\"{site_title} &mdash; Built with {WooCommerce}\";}i:11;a:2:{i:0;s:15:\"admin@gmail.com\";i:1;s:15:\"admin@gmail.com\";}i:12;a:2:{i:0;s:9:\"order-pay\";i:1;s:9:\"order-pay\";}i:13;a:2:{i:0;s:14:\"order-received\";i:1;s:14:\"order-received\";}i:14;a:2:{i:0;s:6:\"orders\";i:1;s:6:\"orders\";}i:15;a:2:{i:0;s:10:\"view-order\";i:1;s:10:\"view-order\";}i:16;a:2:{i:0;s:9:\"downloads\";i:1;s:9:\"downloads\";}i:17;a:2:{i:0;s:12:\"edit-account\";i:1;s:12:\"edit-account\";}i:18;a:2:{i:0;s:12:\"edit-address\";i:1;s:12:\"edit-address\";}i:19;a:2:{i:0;s:15:\"payment-methods\";i:1;s:15:\"payment-methods\";}i:20;a:2:{i:0;s:13:\"lost-password\";i:1;s:13:\"lost-password\";}i:21;a:2:{i:0;s:15:\"customer-logout\";i:1;s:15:\"customer-logout\";}i:22;a:2:{i:0;s:18:\"add-payment-method\";i:1;s:18:\"add-payment-method\";}i:23;a:2:{i:0;s:21:\"delete-payment-method\";i:1;s:21:\"delete-payment-method\";}i:24;a:2:{i:0;s:26:\"set-default-payment-method\";i:1;s:26:\"set-default-payment-method\";}i:25;a:2:{i:0;s:237:\"Thông tin cá nhân của bạn sẽ được sử dụng để xử lý đơn hàng, tăng trải nghiệm sử dụng website, và cho các mục đích cụ thể khác đã được mô tả trong [privacy_policy] của chúng tôi.\";i:1;s:237:\"Thông tin cá nhân của bạn sẽ được sử dụng để xử lý đơn hàng, tăng trải nghiệm sử dụng website, và cho các mục đích cụ thể khác đã được mô tả trong [privacy_policy] của chúng tôi.\";}}');
