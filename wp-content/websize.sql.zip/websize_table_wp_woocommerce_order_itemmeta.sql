
-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_woocommerce_order_itemmeta`
--

INSERT INTO `wp_woocommerce_order_itemmeta` (`meta_id`, `order_item_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_product_id', '14'),
(2, 1, '_variation_id', '0'),
(3, 1, '_qty', '3'),
(4, 1, '_tax_class', ''),
(5, 1, '_line_subtotal', '35970000'),
(6, 1, '_line_subtotal_tax', '0'),
(7, 1, '_line_total', '35970000'),
(8, 1, '_line_tax', '0'),
(9, 1, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(10, 2, 'method_id', 'free_shipping'),
(11, 2, 'instance_id', '1'),
(12, 2, 'cost', '0'),
(13, 2, 'total_tax', '0'),
(14, 2, 'taxes', 'a:1:{s:5:\"total\";a:0:{}}'),
(15, 2, 'Mặt hàng', 'Insta360 One X3 , Mới 100% (Chính hãng) &times; 3'),
(16, 3, '_product_id', '79'),
(17, 3, '_variation_id', '85'),
(18, 3, '_qty', '1'),
(19, 3, '_tax_class', ''),
(20, 3, '_line_subtotal', '16000000'),
(21, 3, '_line_subtotal_tax', '0'),
(22, 3, '_line_total', '9600000'),
(23, 3, '_line_tax', '0'),
(24, 3, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(25, 3, 'pa_tuy-chon', 'chi-body'),
(26, 3, 'pa_mau-sac', 'den'),
(27, 4, '_product_id', '119'),
(28, 4, '_variation_id', '0'),
(29, 4, '_qty', '2'),
(30, 4, '_tax_class', ''),
(31, 4, '_line_subtotal', '137780000'),
(32, 4, '_line_subtotal_tax', '0'),
(33, 4, '_line_total', '82668000'),
(34, 4, '_line_tax', '0'),
(35, 4, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(36, 5, '_product_id', '130'),
(37, 5, '_variation_id', '0'),
(38, 5, '_qty', '1'),
(39, 5, '_tax_class', ''),
(40, 5, '_line_subtotal', '5390000'),
(41, 5, '_line_subtotal_tax', '0'),
(42, 5, '_line_total', '3234000'),
(43, 5, '_line_tax', '0'),
(44, 5, '_line_tax_data', 'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'),
(45, 6, 'method_id', 'free_shipping'),
(46, 6, 'instance_id', '1'),
(47, 6, 'cost', '0'),
(48, 6, 'total_tax', '0'),
(49, 6, 'taxes', 'a:1:{s:5:\"total\";a:0:{}}'),
(50, 6, 'Mặt hàng', 'Sony ZV-E10 (Body) (Màu đen), Mới 100% (Chính hãng) &times; 1, Canon EOS R + RF 24-105mm F4L, Mới 100%(Chính Hãng) &times; 2, Máy in Canon SELPHY CP1500, Mới 100% (Chính hãng) &times; 1'),
(51, 7, 'discount_amount', '63668000'),
(52, 7, 'discount_amount_tax', '0'),
(53, 7, 'coupon_data', 'a:25:{s:2:\"id\";i:203;s:4:\"code\";s:14:\"tienanhmaidinh\";s:6:\"amount\";s:2:\"40\";s:6:\"status\";s:7:\"publish\";s:12:\"date_created\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-04-27 07:40:05.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"date_modified\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-04-27 07:40:05.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:12:\"date_expires\";O:11:\"WC_DateTime\":4:{s:13:\"\0*\0utc_offset\";i:0;s:4:\"date\";s:26:\"2023-04-30 00:00:00.000000\";s:13:\"timezone_type\";i:1;s:8:\"timezone\";s:6:\"+00:00\";}s:13:\"discount_type\";s:7:\"percent\";s:11:\"description\";s:0:\"\";s:11:\"usage_count\";i:0;s:14:\"individual_use\";b:0;s:11:\"product_ids\";a:0:{}s:20:\"excluded_product_ids\";a:0:{}s:11:\"usage_limit\";i:0;s:20:\"usage_limit_per_user\";i:0;s:22:\"limit_usage_to_x_items\";N;s:13:\"free_shipping\";b:1;s:18:\"product_categories\";a:0:{}s:27:\"excluded_product_categories\";a:0:{}s:18:\"exclude_sale_items\";b:0;s:14:\"minimum_amount\";s:0:\"\";s:14:\"maximum_amount\";s:0:\"\";s:18:\"email_restrictions\";a:0:{}s:7:\"virtual\";b:0;s:9:\"meta_data\";a:0:{}}');
