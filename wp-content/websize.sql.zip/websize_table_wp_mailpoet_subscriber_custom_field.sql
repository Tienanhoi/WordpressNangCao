
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_subscriber_custom_field`
--

CREATE TABLE `wp_mailpoet_subscriber_custom_field` (
  `id` int(11) UNSIGNED NOT NULL,
  `subscriber_id` int(11) UNSIGNED NOT NULL,
  `custom_field_id` int(11) UNSIGNED NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
