
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_subscriber_ips`
--

CREATE TABLE `wp_mailpoet_subscriber_ips` (
  `ip` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
