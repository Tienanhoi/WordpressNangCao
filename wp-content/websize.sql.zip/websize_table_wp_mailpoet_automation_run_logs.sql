
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_automation_run_logs`
--

CREATE TABLE `wp_mailpoet_automation_run_logs` (
  `id` int(11) UNSIGNED NOT NULL,
  `automation_run_id` int(11) UNSIGNED NOT NULL,
  `step_id` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  `error` longtext DEFAULT NULL,
  `data` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
