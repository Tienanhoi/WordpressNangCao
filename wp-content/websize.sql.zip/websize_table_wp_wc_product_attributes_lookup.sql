
-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_product_attributes_lookup`
--

CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_wc_product_attributes_lookup`
--

INSERT INTO `wp_wc_product_attributes_lookup` (`product_id`, `product_or_parent_id`, `taxonomy`, `term_id`, `is_variation_attribute`, `in_stock`) VALUES
(14, 14, 'pa_mau-sac', 18, 0, 1),
(37, 37, 'pa_mau-sac', 19, 0, 1),
(48, 48, 'pa_mau-sac', 19, 0, 1),
(55, 55, 'pa_mau-sac', 18, 0, 1),
(64, 64, 'pa_mau-sac', 18, 0, 1),
(85, 79, 'pa_mau-sac', 18, 1, 1),
(86, 79, 'pa_mau-sac', 18, 1, 1),
(85, 79, 'pa_mau-sac', 19, 1, 1),
(86, 79, 'pa_mau-sac', 19, 1, 1),
(85, 79, 'pa_tuy-chon', 21, 1, 1),
(86, 79, 'pa_tuy-chon', 22, 1, 1),
(100, 87, 'pa_mau-sac', 18, 1, 1),
(117, 107, 'pa_mau-sac', 18, 1, 1),
(210, 210, 'pa_mau-sac', 18, 0, 1),
(274, 274, 'pa_mau-sac', 18, 0, 1),
(297, 296, 'pa_mau-sac', 18, 1, 1),
(299, 299, 'pa_mau-sac', 18, 0, 1),
(300, 300, 'pa_mau-sac', 18, 0, 1),
(302, 301, 'pa_mau-sac', 18, 1, 1),
(306, 305, 'pa_mau-sac', 18, 1, 1),
(307, 305, 'pa_mau-sac', 18, 1, 1),
(306, 305, 'pa_mau-sac', 19, 1, 1),
(307, 305, 'pa_mau-sac', 19, 1, 1),
(306, 305, 'pa_tuy-chon', 21, 1, 1),
(307, 305, 'pa_tuy-chon', 22, 1, 1),
(312, 312, 'pa_mau-sac', 18, 0, 1),
(314, 314, 'pa_mau-sac', 19, 0, 1),
(316, 316, 'pa_mau-sac', 19, 0, 1),
(318, 318, 'pa_mau-sac', 18, 0, 1),
(319, 319, 'pa_mau-sac', 18, 0, 1);
