
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_newsletter_option_fields`
--

CREATE TABLE `wp_mailpoet_newsletter_option_fields` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(90) NOT NULL,
  `newsletter_type` varchar(90) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_mailpoet_newsletter_option_fields`
--

INSERT INTO `wp_mailpoet_newsletter_option_fields` (`id`, `name`, `newsletter_type`, `created_at`, `updated_at`) VALUES
(1, 'isScheduled', 'standard', NULL, '2023-03-30 07:34:33'),
(2, 'scheduledAt', 'standard', NULL, '2023-03-30 07:34:33'),
(3, 'event', 'welcome', NULL, '2023-03-30 07:34:33'),
(4, 'segment', 'welcome', NULL, '2023-03-30 07:34:33'),
(5, 'role', 'welcome', NULL, '2023-03-30 07:34:33'),
(6, 'afterTimeNumber', 'welcome', NULL, '2023-03-30 07:34:33'),
(7, 'afterTimeType', 'welcome', NULL, '2023-03-30 07:34:33'),
(8, 'intervalType', 'notification', NULL, '2023-03-30 07:34:33'),
(9, 'timeOfDay', 'notification', NULL, '2023-03-30 07:34:33'),
(10, 'weekDay', 'notification', NULL, '2023-03-30 07:34:33'),
(11, 'monthDay', 'notification', NULL, '2023-03-30 07:34:33'),
(12, 'nthWeekDay', 'notification', NULL, '2023-03-30 07:34:33'),
(13, 'schedule', 'notification', NULL, '2023-03-30 07:34:33'),
(14, 'group', 'automatic', NULL, '2023-03-30 07:34:33'),
(15, 'event', 'automatic', NULL, '2023-03-30 07:34:33'),
(16, 'sendTo', 'automatic', NULL, '2023-03-30 07:34:33'),
(17, 'segment', 'automatic', NULL, '2023-03-30 07:34:33'),
(18, 'afterTimeNumber', 'automatic', NULL, '2023-03-30 07:34:33'),
(19, 'afterTimeType', 'automatic', NULL, '2023-03-30 07:34:33'),
(20, 'meta', 'automatic', NULL, '2023-03-30 07:34:33'),
(21, 'afterTimeNumber', 're_engagement', NULL, '2023-03-30 07:34:33'),
(22, 'afterTimeType', 're_engagement', NULL, '2023-03-30 07:34:33'),
(23, 'automationId', 'automation', NULL, '2023-03-30 07:34:33'),
(24, 'automationStepId', 'automation', NULL, '2023-03-30 07:34:33');
