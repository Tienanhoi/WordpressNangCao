
-- --------------------------------------------------------

--
-- Table structure for table `wp_mailpoet_user_agents`
--

CREATE TABLE `wp_mailpoet_user_agents` (
  `id` int(11) UNSIGNED NOT NULL,
  `hash` varchar(32) NOT NULL,
  `user_agent` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
