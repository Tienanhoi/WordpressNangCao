
-- --------------------------------------------------------

--
-- Table structure for table `wp_wdsslide`
--

CREATE TABLE `wp_wdsslide` (
  `id` int(11) NOT NULL,
  `slider_id` bigint(20) NOT NULL,
  `title` longtext NOT NULL,
  `type` varchar(128) NOT NULL,
  `image_url` mediumtext NOT NULL,
  `thumb_url` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL,
  `link` mediumtext NOT NULL,
  `order` bigint(20) NOT NULL,
  `target_attr_slide` tinyint(1) NOT NULL,
  `youtube_rel_video` tinyint(1) NOT NULL,
  `video_loop` tinyint(1) NOT NULL,
  `fillmode` varchar(10) NOT NULL,
  `mute` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `wp_wdsslide`
--

INSERT INTO `wp_wdsslide` (`id`, `slider_id`, `title`, `type`, `image_url`, `thumb_url`, `published`, `link`, `order`, `target_attr_slide`, `youtube_rel_video`, `video_loop`, `fillmode`, `mute`) VALUES
(1, 1, '{\"title\":\"Slide 1\",\"att_width\":\"0\",\"att_height\":\"0\",\"video_duration\":\"0\"}', 'image', '{site_url}/wp-content/uploads/2023/04/33-1.jpg', '{site_url}/wp-content/uploads/2023/04/33-1.jpg', 1, '', 1, 0, 0, 0, 'fill', 0),
(2, 1, '{\"title\":\"Slide 2\",\"att_width\":\"0\",\"att_height\":\"0\",\"video_duration\":\"0\"}', 'image', '{site_url}/wp-content/uploads/2023/04/34.png', '{site_url}/wp-content/uploads/2023/04/34.png', 1, '', 2, 0, 0, 0, 'fill', 0),
(3, 1, '{\"title\":\"Slide 3\",\"att_width\":\"0\",\"att_height\":\"0\",\"video_duration\":\"0\"}', 'image', '{site_url}/wp-content/uploads/2023/04/35-1.jpg', '{site_url}/wp-content/uploads/2023/04/35-1.jpg', 1, '', 3, 0, 0, 0, 'fill', 0);
